var searchData=
[
  ['observesatisfaction_216',['observeSatisfaction',['../classFloorStaff.html#a74cb50a2de18bdc716559a92a3c58c45',1,'FloorStaff::observeSatisfaction()'],['../classHeadChef.html#abf68a0b8b5f424026e9e1b7945a21d48',1,'HeadChef::observeSatisfaction()'],['../classManager.html#aa4e6668fa7a291904f6fd9f460fdd838',1,'Manager::observeSatisfaction()'],['../classWaiter.html#a2b89a2499fc82b7254f456a925d9a0c8',1,'Waiter::observeSatisfaction()']]],
  ['order_217',['Order',['../classOrder.html#a03e036eb1d0c4e201a8b0d52d72d33d4',1,'Order']]]
];
