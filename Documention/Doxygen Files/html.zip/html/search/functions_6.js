var searchData=
[
  ['headchef_207',['HeadChef',['../classHeadChef.html#ac95033bbe3361915ef93af66d162579b',1,'HeadChef']]]
];
