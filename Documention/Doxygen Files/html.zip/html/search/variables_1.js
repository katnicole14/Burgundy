var searchData=
[
  ['observerlist_266',['observerList',['../classRestaurant.html#a7f8c02ba2aa97f449b9c75bf165ad865',1,'Restaurant']]],
  ['observerstate_267',['observerState',['../classFloorStaff.html#ab8cfdfc479b05d93cfb6ded0ede9836f',1,'FloorStaff']]]
];
