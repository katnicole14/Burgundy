var searchData=
[
  ['headchef_49',['HeadChef',['../classHeadChef.html',1,'HeadChef'],['../classHeadChef.html#ac95033bbe3361915ef93af66d162579b',1,'HeadChef::HeadChef()']]]
];
