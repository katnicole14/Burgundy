var searchData=
[
  ['ingredients_265',['Ingredients',['../classIngredient.html#ae5264c27d5e74db0962b17eb0c5c96f6',1,'Ingredient']]]
];
