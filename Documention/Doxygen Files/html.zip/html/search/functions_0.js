var searchData=
[
  ['addingredient_167',['addIngredient',['../classBun.html#a4caaa92be5d23d73719b7c17e8c19418',1,'Bun::addIngredient()'],['../classBurger.html#a88d461867222a5837f966750f3c423f1',1,'Burger::addIngredient()'],['../classBurgerIngred.html#aff1984436cc28217d82e51893b9e8e25',1,'BurgerIngred::addIngredient()'],['../classIngredient.html#a0de51c6d343a8f3fc13513e4f63bcff9',1,'Ingredient::addIngredient()']]],
  ['addorderitem_168',['addOrderItem',['../classChef.html#aeffc21bddfdf514ee76b686db07c676a',1,'Chef::addOrderItem()'],['../classDrinksChef.html#a374abcb3c2dbccd5adfee67af827cee7',1,'DrinksChef::addOrderItem()'],['../classFriesChef.html#ae4aa2157052f31759ffd78fc69bf3027',1,'FriesChef::addOrderItem()'],['../classSauceChef.html#a9a505a03291a56ce159107b75a56480a',1,'SauceChef::addOrderItem()']]],
  ['assignseatnumber_169',['assignSeatNumber',['../classCustomer.html#a2ecc8cca00132122dcd045cdada3142f',1,'Customer']]],
  ['attachobserver_170',['attachObserver',['../classRestaurant.html#a29cda2ef846c5cd4741c2f54546c02ff',1,'Restaurant']]]
];
