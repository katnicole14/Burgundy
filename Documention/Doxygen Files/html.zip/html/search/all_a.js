var searchData=
[
  ['lettuce_55',['Lettuce',['../classLettuce.html',1,'Lettuce'],['../classLettuce.html#a2bf4a1178c7e7dafafe279b8ea9e3ca4',1,'Lettuce::Lettuce()']]]
];
