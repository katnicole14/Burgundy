var searchData=
[
  ['headchef_141',['HeadChef',['../classHeadChef.html',1,'']]]
];
