var searchData=
[
  ['juice_53',['Juice',['../classJuice.html',1,'Juice'],['../classJuice.html#adc6c116e497ecc666525fce994163290',1,'Juice::Juice()']]]
];
