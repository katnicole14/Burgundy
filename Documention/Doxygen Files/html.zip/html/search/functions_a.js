var searchData=
[
  ['makememento_212',['makeMemento',['../classOrder.html#a12972cb087b05d26f97efcc076f6afb4',1,'Order']]],
  ['manager_213',['Manager',['../classManager.html#afad8267c476f333608dae785daae51a7',1,'Manager']]]
];
