var searchData=
[
  ['next_214',['next',['../classIterator.html#aa1438f0cb84740b0a803362762d5921c',1,'Iterator']]],
  ['notify_215',['notify',['../classRestaurant.html#ae9b916c8fa0096be865487cada8845c0',1,'Restaurant']]]
];
