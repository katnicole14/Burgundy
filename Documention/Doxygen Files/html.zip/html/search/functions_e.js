var searchData=
[
  ['receivefinishedmeal_224',['receiveFinishedMeal',['../classColleague.html#ac1cbc3afb7d1297be9ebc69bec7d8c70',1,'Colleague::receiveFinishedMeal()'],['../classHeadChef.html#a1ae8babcbe94a4486f3d6624222e792d',1,'HeadChef::receiveFinishedMeal()'],['../classTable.html#a1a18ad40919d96da22c1a7f843071d21',1,'Table::receiveFinishedMeal()']]],
  ['receiveorder_225',['receiveOrder',['../classColleague.html#a341fbb4c17e0c0c13ecad55103609c8e',1,'Colleague::receiveOrder()'],['../classHeadChef.html#aad00b42aa34162cd03d3d8a6c21c3556',1,'HeadChef::receiveOrder()'],['../classTable.html#a4abe3f5282b64c4c475e19457a30c4c2',1,'Table::receiveOrder()']]]
];
